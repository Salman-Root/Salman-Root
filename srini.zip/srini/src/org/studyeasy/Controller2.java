package org.studyeasy;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Controller2 {
	
	
	@RequestMapping(value="/" , method= RequestMethod.GET)
	public String hello() {
		return "hello";
	}
	@RequestMapping(value="display"  , method = RequestMethod.GET )
	public String display(@RequestParam("firstname") String firstname, Model model) {
		//String firstname=request.getParameter("firstname");
		//request.setAttribute("firstname", firstname);
		
		model.addAttribute("firstname",firstname);
		return "display";
	}
	
	
	

}
